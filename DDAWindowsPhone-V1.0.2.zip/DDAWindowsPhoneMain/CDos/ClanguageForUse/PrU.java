package DDAWindowsPhoneMain.CDos.ClanguageForUse;

public class PrU {
    String text;
    public PrU(String text) {
        this.text = text;
    }

    public String toString() {
        return "over:" + text;
    }
}
